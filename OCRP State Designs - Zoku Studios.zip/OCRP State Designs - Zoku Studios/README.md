So to install these is pretty easy but Ill give you a little guide so you know what ur doing.

Step 1: Download the OCRP vehicles linked here.

Link: https://forum.cfx.re/t/ocrps-leo-vehicle-pack-with-templates/750695

Step 2: Go into the files and find the file called "lspdcars" then open it

Step 3: Make sure you have OpenIV installed and working with a mods folder

Step 4: Go into the "lspdcars" folder and then into each sub folder

Step 5: In each subfolder you will find 3 files look for the .ytd file and drag it into OpenIV

Step 6: Go into OpenIV and open the .ytd file and search for sign

Step 7: Replace the first file that pops up with the livies you got from me in each sub folder.

Step 8: Replace the old.ytd with the new one

Step 9: Drag into ur server files and add to server.cfg

Step 10: Enjoy ur vehicles!

